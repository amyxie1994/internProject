/*$( "#searchSupplier" ).autocomplete({
  source: [ "c++", "java", "php", "coldfusion", "javascript", "asp", "ruby" ]
});

*/
function search()
{  
    var query = document.getElementById("searchSupplier").value;
    $.ajax({
        type:"POST",
        url:"php/supplierOperations.php",
        data: {type:"searchSupplier",query:query},
        dataType: "json",
        success:function(data){
            update(data);        }
    });
}

function load_data(){
 	$.ajax({
 		type: "POST",
        url: "php/supplierOperations.php",
        data: {type:"listSupplier"},
        dataType: "json",
        success:function(data){
            update(data);
        	

        }
 	});
 }
 
function update(data)
{
    var comName;
    var address;
    var conPerson;
    var Email;
    var aliSite;
    var ebsite;
    var skype;
    var fax;
    var phone;
    var role;
    var otherInfo;
    var creator;
    var create_time;

    var old_tbody = document.getElementById("dTable").getElementsByTagName("tbody")[0];
    var tbody = document.createElement('tbody');
    var table = document.getElementById("dTable");


    for (var i = 0; i < data.length; i++) {
        row = data[i];
        supId = row.SupplierId;
        name = row.ComName;
        address = row.Address;
        conPerson = row.ContactPerson;
        email = row.Email;
        aliSite = row.AlibabaSite;
        ebsite = row.Ebsite;
        skype = row.Skype;
        fax = row.Fax;
        phone= row.Phone;
        role = row.Role;
        otherInfo = row.OtherInfo;
        creator = row.Creator;
        create_time = row.Create_time;

        append_table(tbody,supId,name,address,conPerson,email,aliSite,ebsite,skype,fax,phone,role,otherInfo,creator, create_time);
    }
    table.replaceChild(tbody,old_tbody);
}
 function append_table(tbody,supId,name,address,conPerson,email,aliSite,ebsite,skype,fax,phone,role,otherInfo,creator, create_time){
 	
 	var row = tbody.insertRow(0);

 	var cell = row.insertCell(0);
 	cell.innerHTML = supId;
 	cell.style.display = "none";

 	var cell1 = row.insertCell(1);
 	cell1.innerHTML = name;

 	var cell2 = row.insertCell(2);
 	cell2.innerHTML = address;

 	var cell3 = row.insertCell(3);
 	cell3.innerHTML = conPerson;

 	var cell4 = row.insertCell(4);
 	cell4.innerHTML = email;

 	var cell5 = row.insertCell(5);
 	cell5.innerHTML = aliSite;

 	var cell6 = row.insertCell(6);
 	cell6.innerHTML =ebsite;

 	var cell7 = row.insertCell(7);
 	cell7.innerHTML =skype;

 	var cell8 = row.insertCell(8);
 	cell8.innerHTML =fax;

 	var cell9 = row.insertCell(9);
 	cell9.innerHTML =phone;


 	var cell10 = row.insertCell(10);
 	cell10.innerHTML =role;

 	var cell11 = row.insertCell(11);
 	cell11.innerHTML =otherInfo;



 	cell8 = row.insertCell(12);
 	cell8.innerHTML = creator;


	cell8 = row.insertCell(13);
 	cell8.innerHTML = create_time;


 	var cell12 = row.insertCell(14);
 	var btn1 = document.createElement('button');
 	btn1.className = "btn btn-info btn-xs";
 	btn1.onclick = function(){
 		editSupplier(supId);
 	};

 	var temp1 = document.createElement('i');
    temp1.className = "fa fa-pencil-square-o";
    temp1.setAttribute("aria-hidden", "true");

 	var cell13 = row.insertCell(15);
 	var btn2 = document.createElement('button');
 	btn2.className = "btn btn-danger btn-xs";
 	btn2.onclick = function(){
 		deleteSupplier(supId);
 	};

 	var temp2 = document.createElement('i');
    temp2.className = "fa fa-trash-o";
    temp2.setAttribute("aria-hidden", "true");

    btn1.appendChild(temp1);
    cell12.appendChild(btn1);
    btn2.appendChild(temp2);
    cell13.appendChild(btn2);

 }


  function deleteSupplier(SupplierID){
    $.ajax({
        type: "POST",
        url: "php/supplierOperations.php",
        data:{SupplierID:SupplierID,type:"deleteSupplier"},
        dataType: "json",
        success:function(data){
            alert(data);
            location.reload();
        }
    });

 }

function editSupplier(user_id)
{
    alert(user_id);
    window.location = 'editSupplier.php?supplier_id='+supplier_id ;
 }
